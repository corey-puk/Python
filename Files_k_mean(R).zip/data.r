### This code is part of the lab of STAT1400 - UWA.
data <- read.csv("sleep.csv")

col.names <- colnames(data)
col.names <- col.names[-1]

aux <- as.matrix(data[,2:length(data[1,])])
colnames(aux) <- NULL
remove <- NULL
for (i in 1:length(aux[1,])) {
  remove <- c(remove,(1:length(aux[,1]))[is.na(aux[,i])])
}
remove <- unique(remove)
aux <- aux[-remove,]

mammals <- as.vector(data[-remove,1])
colnames(aux) <- col.names

aux.d <- matrix(NA,length(aux[,1]),length(aux[1,])+12)
aux.d[,1:10] <- aux[,1:10]
aux.d[,11]   <- ifelse(aux[,8] == 2,1,0) #Predation - 2
aux.d[,12]   <- ifelse(aux[,8] == 3,1,0) #Predation - 3
aux.d[,13]  <- ifelse(aux[,8] == 4,1,0) #Predation - 4
aux.d[,14]  <- ifelse(aux[,8] == 5,1,0) #Predation - 5
aux.d[,15]  <- ifelse(aux[,9] == 2,1,0) #Exposure - 2
aux.d[,16]  <- ifelse(aux[,9] == 3,1,0) #Exposure - 3
aux.d[,17]  <- ifelse(aux[,9] == 4,1,0) #Exposure - 4
aux.d[,18]  <- ifelse(aux[,9] == 5,1,0) #Exposure - 5
aux.d[,19]  <- ifelse(aux[,10] == 2,1,0) #Danger - 2
aux.d[,20]  <- ifelse(aux[,10] == 3,1,0) #Danger - 3
aux.d[,21]  <- ifelse(aux[,10] == 4,1,0) #Danger - 4
aux.d[,22]  <- ifelse(aux[,10] == 5,1,0) #Danger - 5

col.names <- c(col.names[1:10],
               "Predation2","Predation3","Predation4","Predation5",
               "Exposure2","Exposure3","Exposure4","Exposure5",
               "Danger2","Danger3","Danger4","Danger5")

colnames(aux.d) <- col.names
data <- aux.d
rm(aux.d,col.names,aux,remove,i)
