#library(shiny)
source("run.r")

# Define UI for dataset viewer app ----
ui <- fluidPage(

  # App title ----
  titlePanel("Cluster"),

  # Sidebar layout with input and output definitions ----
  sidebarLayout(

    # Sidebar panel for inputs ----
    sidebarPanel(
      # Input: Selector for choosing dataset ----
      selectInput(inputId = "dataset",
                  label = "Choose a dataset:",
                  choices = c("original", "standardized", "log", "standardized log")),

      # Input: Numeric entry for number of obs to view ----
      sliderInput(inputId = "cluster",
                  label = "Number of clusters:",
                  min = 1,
                  max = 8,
                  value = 4)
    ),

    # Main panel for displaying outputs ----
    mainPanel(
      # Output: Plot ----
      plotOutput(outputId = "distPlot")
    )
  )
)

# Define server logic to summarize and view selected dataset ----
server <- function(input, output) {

  # Return the requested dataset ----
  # By declaring datasetInput as a reactive expression we ensure
  # that:
  #
  # 1. It is only called when the inputs it depends on changes
  # 2. The computation and result are shared by all the callers,
  #    i.e. it only executes a single time
  datasetInput <- reactive({
    if (input$dataset == "original") {
      out <- data[,c(1,7)]
      colnames(out) <- c("BodyWt (kg)","Gestation (days)")
      return(out)
    } else if (input$dataset == "standardized") {
      out <- standardize(data[,c(1,7)])
      colnames(out) <- c("Std. BodyWt (kg)","Std. Gestation (days)")
      return(out)
    } else if (input$dataset == "log") {
      out <- log(data[,c(1,7)])
      colnames(out) <- c("BodyWt (log(kg))","Gestation (log(days))")
      return(out)
    } else if (input$dataset == "standardized log") {
      out <- standardize(log(data[,c(1,7)]))
      colnames(out) <- c("Std. BodyWt (log(kg))","Std. Gestation (log(days))")
      return(out)
    }
  })

  output$distPlot <- renderPlot({
    x <- datasetInput()
    cluster.plot(x,input$cluster,mammals)
    },width=600,height=600)

}

# Create Shiny app ----
shinyApp(ui, server)
