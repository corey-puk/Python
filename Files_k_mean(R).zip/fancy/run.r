### This code is part of the lab of STAT3406 & 4067 - UWA.

###############################################
standardize <- function(x) {
  if (is.matrix(x)) {
    n <- length(x[,1])
    out <- matrix(NA,length(x[,1]),length(x[1,]))
    for (i in 1:length(x[1,])) {
      out[,i] <- (x[,i] - mean(x[,i]))/(sd(x[,i])*sqrt((n-1)/n))
    }
    if (!is.null(colnames(x))) {
      colnames(out) <- colnames(x)
    }
  } else {
    n <- length(x)
    out <- (x - mean(x))/(sd(x)*sqrt((n-1)/n))
  }
  return(out)
}

###############################################
cluster.plot <- function(x,clusters=2,label=NULL) {
  if ((!is.matrix(x)) && (length(x[1,]) == 2))
    stop("x must be a matrix with two columns.")

  if ((length(clusters) == 1) && (clusters %% 1 == 0)) {
    cluster <- kmeans(x,clusters)
  } else if ((length(clusters) == length(x[,1])) && all(clusters %% 1 == 0)) {
    cluster <- clusters
  } else {
    stop("clusters must be a integer number, or a vector of integer numbers (of size equal do number of lines of x).")
  }

  #define de size of the axis (increasing the default size).
  alpha <- 0.2 #must be >= 0
  xlim <- c(min(x[,1])-max(abs(c(min(x[,1]),max(x[,1]))))*alpha,
            max(x[,1])+max(abs(c(min(x[,1]),max(x[,1]))))*alpha)
  ylim <- c(min(x[,2])-max(abs(c(min(x[,2]),max(x[,2]))))*alpha,
            max(x[,2])+max(abs(c(min(x[,2]),max(x[,2]))))*alpha)

  plot(x,pch=19,cex=0.6,col="white",xlim=xlim,ylim=ylim)
  for (i in 1:length(unique(cluster$cluster))) {
    if (is.null(label)) {
      points(x[cluster$cluster == i,1],x[cluster$cluster == i,2],pch=19,cex=1,col=i)
    } else {
      text(x[cluster$cluster == i,1],x[cluster$cluster == i,2],
           labels = label[cluster$cluster == i], pos = 1, cex=1, col=i)
    }
  }
}

###############################################
###############################################
data <- read.csv("sleep.csv")

col.names <- colnames(data)
col.names <- col.names[-1]

aux <- as.matrix(data[,2:length(data[1,])])
colnames(aux) <- NULL
remove <- NULL
for (i in 1:length(aux[1,])) {
  remove <- c(remove,(1:length(aux[,1]))[is.na(aux[,i])])
}
remove <- unique(remove)
aux <- aux[-remove,]

mammals <- as.vector(data[-remove,1])
colnames(aux) <- col.names

aux.d <- matrix(NA,length(aux[,1]),length(aux[1,])+12)
aux.d[,1:10] <- aux[,1:10]
aux.d[,11]   <- ifelse(aux[,8] == 2,1,0) #Predation - 2
aux.d[,12]   <- ifelse(aux[,8] == 3,1,0) #Predation - 3
aux.d[,13]  <- ifelse(aux[,8] == 4,1,0) #Predation - 4
aux.d[,14]  <- ifelse(aux[,8] == 5,1,0) #Predation - 5
aux.d[,15]  <- ifelse(aux[,9] == 2,1,0) #Exposure - 2
aux.d[,16]  <- ifelse(aux[,9] == 3,1,0) #Exposure - 3
aux.d[,17]  <- ifelse(aux[,9] == 4,1,0) #Exposure - 4
aux.d[,18]  <- ifelse(aux[,9] == 5,1,0) #Exposure - 5
aux.d[,19]  <- ifelse(aux[,10] == 2,1,0) #Danger - 2
aux.d[,20]  <- ifelse(aux[,10] == 3,1,0) #Danger - 3
aux.d[,21]  <- ifelse(aux[,10] == 4,1,0) #Danger - 4
aux.d[,22]  <- ifelse(aux[,10] == 5,1,0) #Danger - 5

col.names <- c(col.names[1:10],
               "Predation2","Predation3","Predation4","Predation5",
               "Exposure2","Exposure3","Exposure4","Exposure5",
               "Danger2","Danger3","Danger4","Danger5")

colnames(aux.d) <- col.names
data <- aux.d
rm(aux.d,col.names,aux,remove,i)
