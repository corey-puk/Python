###############################################
standardize <- function(x) {
  if (is.matrix(x)) {
    n <- length(x[,1])
    out <- matrix(NA,length(x[,1]),length(x[1,]))
    for (i in 1:length(x[1,])) {
      out[,i] <- (x[,i] - mean(x[,i]))/(sd(x[,i])*sqrt((n-1)/n))
    }
    if (!is.null(colnames(x))) {
      colnames(out) <- colnames(x)
    }
  } else {
    n <- length(x)
    out <- (x - mean(x))/(sd(x)*sqrt((n-1)/n))
  }
  return(out)
}

###############################################
cluster.plot <- function(x,clusters=2,label=NULL) {
  if ((!is.matrix(x)) && (length(x[1,]) == 2))
    stop("x must be a matrix with two columns.")

  if ((length(clusters) == 1) && (clusters %% 1 == 0)) {
    cluster <- kmeans(x,clusters)
  } else if ((length(clusters) == length(x[,1])) && all(clusters %% 1 == 0)) {
    cluster <- clusters
  } else {
    stop("clusters must be a integer number, or a vector of integer numbers (of size equal do number of lines of x).")
  }

  #define de size of the axis (increasing the default size).
  alpha <- 0.2 #must be >= 0
  xlim <- c(min(x[,1])-max(abs(c(min(x[,1]),max(x[,1]))))*alpha,
            max(x[,1])+max(abs(c(min(x[,1]),max(x[,1]))))*alpha)
  ylim <- c(min(x[,2])-max(abs(c(min(x[,2]),max(x[,2]))))*alpha,
            max(x[,2])+max(abs(c(min(x[,2]),max(x[,2]))))*alpha)

  plot(x,pch=19,cex=0.6,col="white",xlim=xlim,ylim=ylim)
  for (i in 1:length(unique(cluster$cluster))) {
    if (is.null(label)) {
      points(x[cluster$cluster == i,1],x[cluster$cluster == i,2],pch=19,cex=0.6,col=i)
    } else {
      text(x[cluster$cluster == i,1],x[cluster$cluster == i,2],
           labels = label[cluster$cluster == i], pos = 1, cex=0.6, col=i)
    }
  }
}
